from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="X-Trade Demo")
app.mount("/web", StaticFiles(directory="web", html=True), name="web")

@app.get("/health")
def health():
    return {"ok": True}
