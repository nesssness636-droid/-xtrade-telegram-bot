import os
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.types import Message, WebAppInfo, MenuButtonWebApp
from aiogram.filters import CommandStart

TOKEN = os.environ["BOT_TOKEN"]
WEBAPP_URL = os.environ.get("WEBAPP_URL", "https://YOUR-DOMAIN.example/web/")

dp = Dispatcher()

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "Открой торговый помощник через кнопку Menu.\n"
        "Это учебная версия: сигналы не гарантируют прибыль."
    )

async def main():
    bot = Bot(TOKEN)
    await bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(
            text="X-Trade",
            web_app=WebAppInfo(url=WEBAPP_URL),
        )
    )
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
